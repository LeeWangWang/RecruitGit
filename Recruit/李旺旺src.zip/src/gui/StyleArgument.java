package gui;

import java.awt.Font;

public interface StyleArgument {
	int FONTSIZE = 16;
	String FONTNAME = "����";
	int FONTSTYLE = Font.PLAIN;
}