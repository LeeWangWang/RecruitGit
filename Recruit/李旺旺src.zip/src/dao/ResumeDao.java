/**@FileName: ResumeDao.java
 * @Description: 
 * @Paclage: dao
 * @Author: ������
 * @Data: 2019��1��4������2:25:55
 */
package dao;

import java.util.List;
import bean.Resume;

/**@ClassName: ResumeDao.java
 * @Description: 
 * @Extends: 
 * @Implements: 
 * @Author: ������
 * @Data: 2019��1��4������2:25:55
 */
public interface ResumeDao {
	boolean addResume(Resume r) throws Exception;
	boolean deleteResume(int candidateId) throws Exception;
	List<Resume> searchAll() throws Exception;
	List<Resume> searchByCandidateId(int candidateId) throws Exception;
	List<Resume> searchByPositionId(String gender) throws Exception;
	List<Resume> searchByIsInterview(int interview) throws Exception;
	boolean updateResume(Resume r) throws Exception;
}
