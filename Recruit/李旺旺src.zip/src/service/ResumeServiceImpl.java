/**@FileName: ResumeServiceImpl.java
 * @Description: 
 * @Paclage: service
 * @Author: ������
 * @Data: 2019��1��4������3:17:49
 */
package service;

import java.util.List;
import bean.Resume;
import dao.ResumeDao;

/**@ClassName: ResumeServiceImpl.java
 * @Description: 
 * @Extends: 
 * @Implements: 
 * @Author: ������
 * @Data: 2019��1��4������3:17:49
 */
public class ResumeServiceImpl implements ResumeService {
	private ResumeDao resumeDao;	
	public ResumeServiceImpl(ResumeDao resumeDao) {
		super();
		this.resumeDao = resumeDao;
	}

	public List<Resume> searchAll() {
		try {
			return resumeDao.searchAll();
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
