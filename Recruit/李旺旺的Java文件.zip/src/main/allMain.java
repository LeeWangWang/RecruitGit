package main;

import gui.registerGUI;

public class allMain {
	public static void main(String[] args) {
		new registerGUI();
	}
}
